1.jpeg - https://pixabay.com/photos/mountains-landscape-snow-5727541/
2.jpeg - https://pixabay.com/photos/mountain-cloud-peak-sea-of-clouds-5678172/
3.jpeg - https://pixabay.com/photos/yellowstone-national-park-wyoming-1581879/
4.jpeg - https://pixabay.com/photos/earth-lights-environment-globe-1149733/

Pixabay License (https://pixabay.com/service/license/)
