#
# Module for hcaptcha verifications
#

from flask_hcaptcha import hCaptcha

hcaptcha = hCaptcha()
