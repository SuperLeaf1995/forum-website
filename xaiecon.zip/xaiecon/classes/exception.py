class XaieconException(Exception):
	pass

class XaieconDatabaseException(Exception):
	pass
